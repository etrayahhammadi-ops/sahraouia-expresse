from sqlalchemy import Column, Integer, String, Float
from database import Base

class Hub(Base):
    __tablename__ = "hubs"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    lat = Column(Float, nullable=False)
    lon = Column(Float, nullable=False)
    color_code = Column(String, nullable=True)  # e.g., #D4A373
