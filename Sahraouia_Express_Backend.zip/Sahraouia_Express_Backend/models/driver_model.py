from sqlalchemy import Column, Integer, String, Float, Boolean
from database import Base

class Driver(Base):
    __tablename__ = "drivers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    hub_id = Column(Integer, nullable=True)
    active = Column(Boolean, default=True)
    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)
