from sqlalchemy import Column, Integer, String, Float, Enum
from database import Base
import enum

class OrderStatus(str, enum.Enum):
    created = "created"
    assigned = "assigned"
    enroute = "enroute"
    delivered = "delivered"
    failed = "failed"

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    address_text = Column(String, nullable=True)
    plus_code = Column(String, nullable=True)
    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)
    zone = Column(String, nullable=True)  # e.g., LAAYOUNE / BOUJDOUR / DAKHLA
    cod_amount = Column(Float, nullable=True, default=0.0)
    status = Column(Enum(OrderStatus), nullable=False, default=OrderStatus.created)
