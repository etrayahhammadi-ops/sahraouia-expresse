# Sahraouia Express API (FastAPI + PostgreSQL)

Production-ready backend for Sahraouia Express logistics (Laâyoune ⇄ Dakhla).
Maintainer: **etrayahhammadi-ops**

## 🚀 One-click Deploy on Railway
1) Push this folder to a new GitHub repo (e.g., `sahraouia_express_backend`).
2) Go to https://railway.app → New Project → Deploy from GitHub.
3) Add environment variables (Railway → Variables):
   - `DATABASE_URL` = PostgreSQL connection string (Railway plugin, Neon, or Supabase).
   - `APP_NAME` = "Sahraouia Express API"
   - `CORS_ORIGINS` = "*" (or your dashboard/app domains)
4) Railway will detect the Procfile and start `uvicorn` automatically.
5) Open `/docs` for interactive API.

## 🧱 Tech
- FastAPI, SQLAlchemy 2.0
- PostgreSQL (psycopg2)
- Uvicorn on Railway
- Simple routing/ETA placeholders to extend later

## ▶️ Local run (optional)
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # then edit DATABASE_URL or keep empty for SQLite dev
uvicorn main:app --reload
```

## 📦 Structure
```
main.py
database.py
models/
routes/
services/
utils/
requirements.txt
Procfile
.env.example
README.md
```
