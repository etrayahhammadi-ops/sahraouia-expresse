import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

APP_NAME = os.getenv("APP_NAME", "Sahraouia Express API")
CORS = os.getenv("CORS_ORIGINS", "*")
origins = [o.strip() for o in CORS.split(",") if o.strip()] or ["*"]

app = FastAPI(title=APP_NAME, version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
from routes.orders import router as orders_router
from routes.drivers import router as drivers_router
from routes.hubs import router as hubs_router

app.include_router(orders_router, prefix="/api/orders", tags=["Orders"])
app.include_router(drivers_router, prefix="/api/drivers", tags=["Drivers"])
app.include_router(hubs_router, prefix="/api/hubs", tags=["Hubs"])

@app.get("/")
def root():
    return {"message": "🚚 Welcome to Sahraouia Express API", "ok": True}

@app.get("/healthz")
def healthz():
    return {"status": "healthy"}
