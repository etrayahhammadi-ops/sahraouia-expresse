from geopy.distance import distance

def km_between(a_lat: float, a_lon: float, b_lat: float, b_lon: float) -> float:
    return distance((a_lat, a_lon), (b_lat, b_lon)).km
