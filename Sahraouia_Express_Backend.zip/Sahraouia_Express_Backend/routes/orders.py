from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db, Base, engine
from models.order_model import Order, OrderStatus
from pydantic import BaseModel, Field
from typing import Optional, List

# Create tables if not exist (simple auto-migrate for MVP)
Base.metadata.create_all(bind=engine)

router = APIRouter()

class OrderIn(BaseModel):
    customer_name: str
    phone: str
    address_text: Optional[str] = None
    plus_code: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    zone: Optional[str] = None
    cod_amount: Optional[float] = 0.0

class OrderOut(BaseModel):
    id: int
    customer_name: str
    phone: str
    status: OrderStatus
    zone: Optional[str] = None
    cod_amount: Optional[float] = 0.0
    class Config:
        from_attributes = True

@router.get("/", response_model=List[OrderOut])
def list_orders(db: Session = Depends(get_db)):
    return db.query(Order).order_by(Order.id.desc()).limit(200).all()

@router.post("/create", response_model=OrderOut)
def create_order(payload: OrderIn, db: Session = Depends(get_db)):
    order = Order(
        customer_name=payload.customer_name,
        phone=payload.phone,
        address_text=payload.address_text,
        plus_code=payload.plus_code,
        lat=payload.lat,
        lon=payload.lon,
        zone=payload.zone,
        cod_amount=payload.cod_amount,
        status=OrderStatus.created,
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    return order

@router.post("/{order_id}/status/{status}", response_model=OrderOut)
def set_status(order_id: int, status: OrderStatus, db: Session = Depends(get_db)):
    order = db.query(Order).get(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    order.status = status
    db.commit()
    db.refresh(order)
    return order
