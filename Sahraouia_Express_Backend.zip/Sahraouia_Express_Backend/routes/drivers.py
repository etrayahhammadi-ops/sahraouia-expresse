from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db, Base, engine
from models.driver_model import Driver
from pydantic import BaseModel
from typing import List, Optional

Base.metadata.create_all(bind=engine)

router = APIRouter()

class DriverIn(BaseModel):
    name: str
    phone: str
    hub_id: Optional[int] = None
    lat: Optional[float] = None
    lon: Optional[float] = None

class DriverOut(BaseModel):
    id: int
    name: str
    phone: str
    hub_id: Optional[int] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    class Config:
        from_attributes = True

@router.get("/", response_model=List[DriverOut])
def list_drivers(db: Session = Depends(get_db)):
    return db.query(Driver).order_by(Driver.id.desc()).limit(200).all()

@router.post("/create", response_model=DriverOut)
def create_driver(payload: DriverIn, db: Session = Depends(get_db)):
    d = Driver(name=payload.name, phone=payload.phone, hub_id=payload.hub_id, lat=payload.lat, lon=payload.lon)
    db.add(d)
    db.commit()
    db.refresh(d)
    return d

@router.post("/{driver_id}/location")
def update_location(driver_id: int, lat: float, lon: float, db: Session = Depends(get_db)):
    d = db.query(Driver).get(driver_id)
    if not d:
        raise HTTPException(status_code=404, detail="Driver not found")
    d.lat, d.lon = lat, lon
    db.commit()
    return {"ok": True, "driver_id": driver_id, "lat": lat, "lon": lon}
