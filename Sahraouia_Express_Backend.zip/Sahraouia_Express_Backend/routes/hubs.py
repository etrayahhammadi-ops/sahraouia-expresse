from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db, Base, engine
from models.hub_model import Hub
from pydantic import BaseModel
from typing import List

Base.metadata.create_all(bind=engine)

router = APIRouter()

class HubIn(BaseModel):
    name: str
    lat: float
    lon: float
    color_code: str

class HubOut(BaseModel):
    id: int
    name: str
    lat: float
    lon: float
    color_code: str
    class Config:
        from_attributes = True

@router.get("/", response_model=List[HubOut])
def list_hubs(db: Session = Depends(get_db)):
    return db.query(Hub).order_by(Hub.id.asc()).all()

@router.post("/create", response_model=HubOut)
def create_hub(payload: HubIn, db: Session = Depends(get_db)):
    hub = Hub(name=payload.name, lat=payload.lat, lon=payload.lon, color_code=payload.color_code)
    db.add(hub)
    db.commit()
    db.refresh(hub)
    return hub
