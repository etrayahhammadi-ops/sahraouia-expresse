# Dispatch policy placeholder (later add cut-off & priority rules)
def should_dispatch_now(backlog_count: int, wave_size: int = 30) -> bool:
    return backlog_count >= wave_size
