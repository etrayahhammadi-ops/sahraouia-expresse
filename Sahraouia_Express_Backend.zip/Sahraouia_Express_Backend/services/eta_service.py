# Simple ETA estimator: distance / avg_speed + fixed buffer
def estimate_minutes(distance_km: float, avg_speed_kmh: float = 35.0, buffer_min: float = 10.0) -> float:
    if avg_speed_kmh <= 0:
        avg_speed_kmh = 35.0
    return (distance_km / avg_speed_kmh) * 60.0 + buffer_min
